#pragma once
#include<Windows.h>
#include<iostream>
#include<stdio.h>
using namespace std;




